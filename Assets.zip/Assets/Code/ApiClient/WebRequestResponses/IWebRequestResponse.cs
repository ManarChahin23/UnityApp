using UnityEngine;

public interface IWebRequestResponse 
{

}
