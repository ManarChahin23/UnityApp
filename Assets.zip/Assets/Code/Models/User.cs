using System;
using UnityEngine;

[Serializable]
public class User
{
    public string email;
    public string password;
}